#!/usr/bin/env python
# /////////////////////////////////////////////////////////////////////////////
#                           CSMA/CA Test Script
#
# FuNLab
# University of Washington
# Morgan Redfield
#
# This script sets up a UHD flow graph that implements OFDM TX and RX.
# The sending and receiving of packets is managed by a CSMA/CA MAC.
#
# This script allows the CSMA/CA MAC to be tested in various ways.
#
# /////////////////////////////////////////////////////////////////////////////


from gnuradio import gr, gru
from gnuradio import uhd
#from gnuradio import usrp
from gnuradio import eng_notation
from gnuradio.eng_option import eng_option
from optparse import OptionParser

import time
import struct
import sys
import os

# from current dir
#using state machine MAC, not while loop MAC (maybe this will work better?)
from csma_ca import *
    

# /////////////////////////////////////////////////////////////////////////////
#                             the flow graph
# /////////////////////////////////////////////////////////////////////////////

class usrp_graph(gr.top_block): #HEREDA DE LA CLASE BLOCK UN BLOQUE HERARQUICO 
    def __init__(self, callback, options):
        gr.top_block.__init__(self)

        self._tx_freq            = 1000         # tranmitter's center frequency
        self._tx_gain            = 10         # transmitter's gain
        self._samp_rate             = 800   # sample rate for USRP
        self._rx_freq            = 1000         # receiver's center frequency
        self._rx_gain            = 10        # receiver's gain

        if self._tx_freq is None:
            sys.stderr.write("-f FREQ or --freq FREQ or --tx-freq FREQ must be specified\n")
            raise SystemExit

        if self._rx_freq is None:
            sys.stderr.write("-f FREQ or --freq FREQ or --rx-freq FREQ must be specified\n")
            raise SystemExit

        # Set up USRP sink and source
        self._setup_usrp_sink()
        self._setup_usrp_source()

#-------------------------fORSOZAMENTE SE CONFIGURA LA FRECUENCIA DE TRANSMISION-----------------------------------------------
        # Set center frequency of USRP
        # ok = self.set_freq(self._tx_freq)
        # if not ok:
        #     print "Failed to set Tx frequency to %s" % (eng_notation.num_to_str(self._tx_freq),)
        #     raise ValueError
#------------------------------------------------------------------------------------------------------------------------------

        
        # if options.verbose:
        #     self._print_verbage()
        # if options.show_rx_gain_range:
        #     print "RX gain range: "
        # if options.show_tx_gain_range:
        #     print "TX gain range: "

    def carrier_sensed(self):
        """
        Return True if the receive path thinks there's carrier
        """
        pass

    def _setup_usrp_sink(self):
        """
        Creates a USRP sink, determines the settings for best bitrate,
        and attaches to the transmitter's subdevice.
        """
        pass

    def _setup_usrp_source(self):
        pass

    def set_freq(self):
        """
        Set the center frequency we're interested in.

        @param target_freq: frequency in Hz
        @rypte: bool

        Tuning is a two step process.  First we ask the front-end to
        tune as close to the desired frequency as it can.  Then we use
        the result of that operation and our target_frequency to
        determine the value for the digital up converter.
        """
        r_snk = (ok,1000)
        r_src = (ok,1000)
        if r_snk and r_src:
            return True

        return False



        pass

    def add_options(normal, expert):
        """
        Adds usrp-specific options to the Options Parser
        """
        add_freq_option(normal)
        normal.add_option("-v", "--verbose", action="store_true", default=False)
        expert.add_option("", "--rx-freq", type="eng_float", default=None,
                          help="set Rx frequency to FREQ [default=%default]", metavar="FREQ")
        expert.add_option("", "--tx-freq", type="eng_float", default=None,
                          help="set Tx frequency to FREQ [default=%default]", metavar="FREQ")
        expert.add_option("-r", "--samp_rate", type="intx", default=800000,
                           help="set sample rate for USRP to SAMP_RATE [default=%default]")
        normal.add_option("", "--rx-gain", type="eng_float", default=14, metavar="GAIN",
                          help="set receiver gain in dB [default=%default].  See also --show-rx-gain-range")
        normal.add_option("", "--show-rx-gain-range", action="store_true", default=False, 
                          help="print min and max Rx gain available")        
        normal.add_option("", "--tx-gain", type="eng_float", default=11.75, metavar="GAIN",
                          help="set transmitter gain in dB [default=%default].  See also --show-tx-gain-range")
        normal.add_option("", "--show-tx-gain-range", action="store_true", default=False, 
                          help="print min and max Tx gain available")
        expert.add_option("", "--snr", type="eng_float", default=30,
                          help="set the SNR of the Rx channel in dB [default=%default]")
    # Make a static method to call before instantiation
    add_options = staticmethod(add_options)

    def _print_verbage(self):
        """
        Prints information about the transmit path
        """
        print
        print "PHY parameters"
        print "samp_rate        %3d"   % (self._samp_rate)
        print "Tx Frequency:    %s"    % (eng_notation.num_to_str(self._tx_freq))
        print "Tx antenna gain  %s"    % (self._tx_gain)
        print "Rx antenna gain  %s"    % (self._rx_gain)
        
def add_freq_option(parser):
    """
    Hackery that has the -f / --freq option set both tx_freq and rx_freq
    """
    def freq_callback(option, opt_str, value, parser):
        parser.values.rx_freq = 1000
        parser.values.tx_freq = 1000

    if not parser.has_option('--freq'):
        parser.add_option('-f', '--freq', type="eng_float",
                          action="callback", callback=freq_callback,
                          help="set Tx and/or Rx frequency to FREQ [default=%default]",
                          metavar="FREQ")


# /////////////////////////////////////////////////////////////////////////////
#                                   main
# /////////////////////////////////////////////////////////////////////////////
pkts_rcvd = []
EOF_rcvd = False
num_acks = 0
def rx_callback(payload):
    global pkts_rcvd
    global EOF_rcvd
    global tx_failures
    global num_acks
    
    print payload

    if payload == "R:EOF":
        EOF_rcvd = True
    if payload[:2] == "R:":
        pkts_rcvd.append(payload)
    elif payload == "T:ACK":
    	num_acks += 1
        


def main():
    global pkts_rcvd
    global EOF_rcvd
    global num_acks
    
    parser = OptionParser (option_class=eng_option, conflict_handler="resolve")
    expert_grp = parser.add_option_group("Expert")
    parser.add_option("-m", "--modulation", type="choice", choices=['bpsk', 'qpsk'],
                      default='bpsk',
                      help="Select modulation from: bpsk, qpsk [default=%%default]")
    parser.add_option("-v","--verbose", action="store_true", default=False)
    parser.add_option("-p","--packets", type="int", default = 40, 
                      help="set number of packets to send [default=%default]")
    parser.add_option("", "--address", type="string", default = None,
                      help="set the address of the node (addresses are a single char) [default=%default]")
    expert_grp.add_option("-c", "--carrier-threshold", type="eng_float", default=-20,
                      help="set carrier detect threshold (dB) [default=%default]")
    parser.add_option("", "--pkt-gen-time", type="eng_float", default=.5,
                      help="set the time between sending each packet (s) [default=%default]")
    parser.add_option("", "--pkt-padding", type="int", default=0,
                      help="pad packet with pkt-padding number of extra chars [default=%default]")
    parser.add_option("", "--test-time", type="int", default=500,
                      help="number of seconds to run the test for [default=%default]")
    

#----------INSTANCIAS------------------------------------
    cs_mac.add_options(parser, expert_grp)
#--------------------------------------------------------

#--------------------------SE ASIGNA UN METODO DE UNA CLASE (OBJETO TUPLA)--------------
    (options, args) = parser.parse_args()
    if len(args) != 0:
        parser.print_help(sys.stderr)
        sys.exit(1)

    # if options.rx_freq is None or options.tx_freq is None:
    #     sys.stderr.write("You must specify -f FREQ or --freq FREQ\n")
    #     parser.print_help(sys.stderr)
    #     sys.exit(1)
    # if options.address is None:
    # 	sys.stderr.write("You must specify a node address\n")
    # 	parser.print_help(sys.stderr)
    # 	sys.exit(1)

    # Attempt to enable realtime scheduling

    pkts_sent = 0
    # instantiate the MAC
    mac = cs_mac(options, rx_callback)


    # build the graph (PHY)
    tx_failures = []
    tb = usrp_graph(mac.phy_rx_callback, options)#------------#SE CREA UN OBJETO TB QUE CUMPLA LAS FUNCIONES DE UN DIAGRAMA GRC DE LA CLASE USRP_GRAPH

    mac.set_flow_graph(tb)    # give the MAC a handle for the PHY
    mac.set_error_array(tx_failures)
    
    print
    print "address:        %s"   % (options.address)
    print
    print "modulation:     %s"   % (options.modulation,)
    print "freq:           %s"   

    #tb.rxpath.set_carrier_threshold(options.carrier_threshold)
    print "Carrier sense threshold:", options.carrier_threshold, "dB"

    tb.start()    # Start executing the flow graph (runs in separate threads)

    mac.start()
    
    print  time.strftime("%X")
    start_time = time.clock()
    while ((pkts_sent < options.packets + 3) or not EOF_rcvd):#-------------------------------MODIFICADO
        if options.verbose:
            print "give a new packet to the MAC"
        if pkts_sent > options.packets:
            mac.new_packet('x', "EOF")
        else:
            mac.new_packet('x', str(pkts_sent).zfill(3) + 2 * "k")    # run the tests
        pkts_sent += 1
    #while not EOF_rcvd:
    #    time.sleep(options.pkt_gen_time)

    while time.clock() - start_time < 2*options.test_time:
    	pass
    print  time.strftime("%X")

    
    mac.stop()
    mac.wait()
    print "total txrx time:    ", time.clock() - start_time
    
    #do stuff with the measurement results
    print
    print "this node sent:     ", pkts_sent, " packets"
    print "there were:         ", len(tx_failures), " packets that were not successfully sent"
    print "this node received: ", num_acks, " ACK packets"
    print "this node rcvd:     ", len(set(pkts_rcvd)), " packets"
    print "there were:         ", len(pkts_rcvd) - len(set(pkts_rcvd)), " spurious packet retransmissions"
    print "collisions:         ", mac.collisions
    if options.pkt_padding != 0:
    	print "the packets this node sent were of length: ", len(str(pkts_sent).zfill(3) + 2 * "k") + 2 # + 2 for the address chars
    #for item in pkts_rcvd:
    #    print "\t", item
    #print "succesfully sent the following packets"
    #for item in mac.sent_pkts:
    #    print "\t", item
    

    
    tb.stop()     # but if it does, tell flow graph to stop.
    tb.wait()     # wait for it to finish
    

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
